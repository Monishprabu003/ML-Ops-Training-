
Engagement_level - v2 2023-10-14 9:07pm
==============================

This dataset was exported via roboflow.com on May 28, 2026 at 3:29 AM GMT

Roboflow is an end-to-end computer vision platform that helps you
* collaborate with your team on computer vision projects
* collect & organize images
* understand and search unstructured image data
* annotate, and create datasets
* export, train, and deploy computer vision models
* use active learning to improve your dataset over time

For state of the art Computer Vision training notebooks you can use with this dataset,
visit https://github.com/roboflow/notebooks

To find over 100k other datasets and pre-trained models, visit https://universe.roboflow.com

The dataset includes 60 images.
Engagement-level are annotated in YOLOv8 format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


